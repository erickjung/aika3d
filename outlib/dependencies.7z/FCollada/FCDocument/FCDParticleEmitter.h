/*
	Copyright (C) 2005-2007 Feeling Software Inc.
	Portions of the code are:
	Copyright (C) 2005-2007 Sony Computer Entertainment America
	
	MIT License: http://www.opensource.org/licenses/mit-license.php
*/

/**
	@file FCDParticleEmitter.h
	This file contains the FCDParticleModifier base class, and 
	its various definitions.
*/

#ifndef _FCD_PARTICLE_EMITTER_H_
#define _FCD_PARTICLE_EMITTER_H_


#endif // _FCD_PARTICLE_EMITTER_H_