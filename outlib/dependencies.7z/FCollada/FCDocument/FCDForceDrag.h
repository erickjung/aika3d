/*
	Copyright (C) 2005-2007 Feeling Software Inc.
	Portions of the code are:
	Copyright (C) 2005-2007 Sony Computer Entertainment America
	
	MIT License: http://www.opensource.org/licenses/mit-license.php
*/

/**
	@file FCDForceDrag.h
	This file contains the FCDForceDrag class.
*/

#ifndef _FCD_FORCE_DRAG_H_
#define _FCD_FORCE_DRAG_H_

#endif // _FCD_FORCE_DRAG_H_
