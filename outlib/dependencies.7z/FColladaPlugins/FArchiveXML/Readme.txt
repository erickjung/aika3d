[GLaforte - 21-06-2007]

FArchiveXML is the default COLLADA archive plug-in.

It is a full-featured plug-in that can be used as a sample to
writing your own archiving plug-in or it can be extended with your
own COLLADA extension.

It is statically loaded by FCollada and parses all .DAE or .XML files.